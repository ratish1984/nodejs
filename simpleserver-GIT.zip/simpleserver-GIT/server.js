//import http module
//import url module
//import path module
//import fs module

// define mimTypes with key: value i.e key=fileextension and value=filetype
// eg: "html": "text/html"

// using http module create server
//declare a variable uri by parsing the pathname of url
//declare a variable filename by using pathjoin with process.cwd() and escape function
//display in log uri variable
//declare stats variable

//using try and catch, in try store all details of filename variable into  stats variable.
//in catch fill header details with 404 and passing a json value of 'Content-type':'text/plain'
//display on pag 404 not found   

//if it is a file check using stats and isFile() function
//declare another variable called mimeType with array of mimeTypes with extension
//name of file and split it with "." and reverse it get the index 0.
//update header details with 200 and json value of 'Content-type': mimeType
//create a fileStream variable and using fs module createReadStream
// passing filename as parameter
//pipe the results of res to fileStream
//use else if checking if its a directory using isDirectory() with stats var
//pass Header as 302 and redirect index.html
//under else pass Header as 500 with json data as text/plain
//using listen(3000)
    
